package com.tutorial.dockersample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
