package io.sunil.productinventoryservice;

public class InventoryModel {

	private String productAvailable;

	private String addToWishlist;
	
	private String productId;

	public InventoryModel(String productAvailable, String addToWishlist,String producId) {
		this.productAvailable = productAvailable;
		this.addToWishlist = addToWishlist;
		this.productId=producId;
	}

	@Override
	public String toString() {
		return "productAvailable :"+productAvailable+" , addToWishlist :"+addToWishlist+", productId :"+productId;
	}
	
	public String getAddToWishlist() {
		return addToWishlist;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getProductId() {
		return productId;
	}
	public void setAddToWishlist(String addToWishlist) {
		this.addToWishlist = addToWishlist;
	}

	public String getProductAvailable() {
		return productAvailable;
	}

	public void setProductAvailable(String productAvailable) {
		this.productAvailable = productAvailable;
	}

}
