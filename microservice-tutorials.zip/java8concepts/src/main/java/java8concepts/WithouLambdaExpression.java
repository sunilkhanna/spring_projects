package java8concepts;


interface myInterface2{
	public void draw();
}

public class WithouLambdaExpression {

	public static void main(String[] args) {

		int width = 10;
		
		myInterface2 mi=new myInterface2() {
			
			public void draw() {
				System.out.println("printing without lambda usesssss");
				
			}
		};
		
		mi.draw();
	}

}
