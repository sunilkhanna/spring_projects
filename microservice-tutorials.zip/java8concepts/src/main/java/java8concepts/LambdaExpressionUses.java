package java8concepts;

import java.util.function.Predicate;

@FunctionalInterface
interface myInterface{
	public void draw();
	public void test11();
}

public class LambdaExpressionUses {

	public static void main(String[] args) {
		int width=10;
		
		myInterface mi=()->{
			System.out.println("Printing with lambdaaaaaaaas");
		};

		
		
		Predicate<Integer> predicate=(Integer x) -> (x%2==0);
		
		Predicate<Integer> predoi=(Integer xx) -> {
			
			return true;
		};
		
		System.out.println("Lmbda Predicate :: "+predicate.test(81));
		
		
		mi.draw();
	}

	
}
