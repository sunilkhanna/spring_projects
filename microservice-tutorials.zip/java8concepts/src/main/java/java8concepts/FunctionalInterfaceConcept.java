package java8concepts;


@FunctionalInterface
interface sayable{
	void sayHello(String message);//abstract method
}

public class FunctionalInterfaceConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
