package sg.com.dbs.ocr.scripting.batchclass.common.highway;

import com.ephesoft.dcma.util.logger.EphesoftLogger;
import com.ephesoft.dcma.util.logger.ScriptLoggerFactory;
import sg.com.dbs.ocr.constants.OCRConstants;
import sg.com.dbs.ocr.scripting.CustomService;
import sg.com.dbs.ocr.scripting.batchclass.common.settlement.SettlementScriptUtils;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.jdom.Document;
import org.jdom.Element;
import sg.com.dbs.ocr.util.OCRUtils;
import sg.com.dbs.ocr.vo.reportDownload.RepTransactionDetails;

import java.util.HashSet;
import org.apache.commons.lang3.StringUtils;
import static sg.com.dbs.ocr.constants.OCRConstants.*;
import static sg.com.dbs.ocr.scripting.batchclass.common.highway.HighwayConstants.WEBSCANNER;

public class HighwayPageLimitUtil {
    protected static EphesoftLogger LOGGER = ScriptLoggerFactory.getLogger(HighwayPageLimitUtil.class);
    int PAGE_LIMIT = 10;

    public void setPageLimitFromCustomizedConfiguration() {
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil setPageLimitFromCustomizedConfiguration");
            String strConfig = new CustomService().getCustomizedConfiguartion("HIGHWAY_PAGE_LIMIT");
            if (StringUtils.isNotBlank(strConfig)) {
                int pageLimitConfig = 0;
                pageLimitConfig = Integer.parseInt(strConfig);
                PAGE_LIMIT = pageLimitConfig;
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil setPageLimitFromCustomizedConfiguration." + e.getMessage());
        }
    }

    public void deleteRedundantPagesForTIF(Document document) {
        int noRemain = 0;
        try {
        	String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil deleteRedundantPagesForTIF: " + bid);            
        	SortedMap<String, String> fileMap = mapInstanceFileBackupFile(document);
        	if (isScannedPageCountMissing(document)) {
        		LOGGER.info("deleteRedundantPagesForTIF missing page: " + bid + fileMap );
        		// comment out copying files from instance folder
        		for (String key : fileMap.keySet()) {
        			Files.copy(new File(key).toPath(), new File(fileMap.get(key)).toPath(), StandardCopyOption.REPLACE_EXISTING);
        		}
        	}
            Element docRoot = document.getRootElement();
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            LOGGER.info("looking for tif file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".tif")) {
                    LOGGER.info("deleteRedundantPagesForTIF " + file.getName() + " - " + bid);
                    Files.copy(file.toPath(), new File(file.getAbsolutePath() + "bk").toPath(), StandardCopyOption.REPLACE_EXISTING);
                    if (noRemain < PAGE_LIMIT) {
                        noRemain = noRemain + 1;
                    } else {
                        if (file.delete()) {
                            LOGGER.info("Deleted");
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteRedundantPagesForTIF." + e.getMessage());
        }
    }

    public void deleteRedundantPagesForPDF(Document document) {
        int noPageKeep = PAGE_LIMIT;
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil deleteRedundantPagesForPDF: " + bid);
            Element docRoot = document.getRootElement();
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            LOGGER.info("looking for pdf file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".pdf")) {
                    Files.copy(file.toPath(), new File(file.getAbsolutePath() + "bk").toPath(), StandardCopyOption.REPLACE_EXISTING);
                    int remainNo = deleteLastPagesForPDFFile(file, noPageKeep);
                    if (remainNo >= 0) {
                        noPageKeep = noPageKeep - remainNo;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteRedundantPagesForPDF." + e.getMessage());
        }
    }

    // return no of page left
    public int deleteLastPagesForPDFFile(File file, int remainNo) {
        PDDocument pdDocument = null;
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil deleteLastPagesForPDFFile: ");
            pdDocument = PDDocument.load(file);
            if (!pdDocument.isEncrypted()) {
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                stripper.setStartPage(1);
                stripper.setEndPage(pdDocument.getNumberOfPages());
                if (remainNo == 0) {
                    if (file.delete()) {
                        return 0;
                    }
                }
                while (pdDocument.getNumberOfPages() > remainNo) {
                    pdDocument.removePage(pdDocument.getNumberOfPages() - 1);
                }
                pdDocument.save(file);
                return pdDocument.getNumberOfPages();
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteLastPagesForPDFFile."  + e.getMessage());
        }
        try {
            if (pdDocument != null) {
                pdDocument.close();
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteLastPagesForPDFFile."  + e.getMessage());
        }
        return -1;
    }

    // return no of page left
    public int deleteFirstPagesForFile(File file, int deleteNo) {
        PDDocument pdDocument = null;
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil deletePagesForFile: ");
            pdDocument = PDDocument.load(file);
            if (!pdDocument.isEncrypted()) {
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                stripper.setStartPage(1);
                stripper.setEndPage(pdDocument.getNumberOfPages());
                int pageNo = pdDocument.getNumberOfPages();
                if (deleteNo >= pageNo) {
                    if (file.delete()) {
                        LOGGER.info("File deleted with page no: " + pageNo);
                    }
                    if (deleteNo == pageNo) {
                        return -1;
                    } else {
                        return deleteNo - pageNo;
                    }
                }
                while (deleteNo > 0) {
                    pdDocument.removePage(0);
                    deleteNo = deleteNo - 1;
                }
                pdDocument.save(file);
                return deleteNo;
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteRedundantPagesForContract."  + e.getMessage());
        }
        try {
            if (pdDocument != null) {
                pdDocument.close();
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil deleteRedundantPagesForContract."  + e.getMessage());
        }
        return deleteNo;
    }

    public boolean isBackupExist(Document document) {
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil isBackupExist: ");
            Element docRoot = document.getRootElement();
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            LOGGER.info("looking for file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".pdfbk") || file.getName().toLowerCase().endsWith(".tifbk")) {
                    return true;
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil isBackupPDFExist."  + e.getMessage());
        }
        return false;
    }

    // return the absolute path of files that not been processed
    public List<String> revertBackupFile(Document document) {
        List<String> result = new ArrayList<>();
        HashSet<String> processedFileSet = new HashSet<>();
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil revertBackupFile: ");
            Element docRoot = document.getRootElement();
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            LOGGER.info("looking for file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".pdf") || file.getName().toLowerCase().endsWith(".tif")) {
                    processedFileSet.add(file.getAbsolutePath());
                    if (file.delete()) {
                        LOGGER.info("revertBackupFile deleted origin processed file");
                    }
                }
            }
            listOfFiles = OCRUtils.getFileLists(folder);
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".pdfbk") || file.getName().toLowerCase().endsWith(".tifbk")) {
                    String newFileName = file.getAbsolutePath();
                    newFileName = newFileName.substring(0, newFileName.length()-2);
                    if (!processedFileSet.contains(newFileName)) {
                        result.add(newFileName);
                    }
                    if (file.renameTo(new File(newFileName))) {
                        LOGGER.info("revertBackupFile file rename to " + newFileName);
                    }
                    if (file.delete()) {
                        LOGGER.info("revertBackupFile deleted backup file");
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil revertBackupFile."  + e.getMessage());
        }
        return result;
    }

    public void copyBackupTIFToInstanceFolder(Document document, List<String> fileNames) {
        try {
            Element docRoot = document.getRootElement();
            String localPath = docRoot.getChildText(BATCH_LOCAL_PATH);
            String bid = docRoot.getChildText(BATCH_INSTANCE_IDENTIFIER);
            LOGGER.info("************* Start HighwayPageLimitUtil copyBackupTifToInstanceFolder: " + bid);
            localPath = localPath + File.separatorChar + bid + File.separatorChar;
            for (String fileName : fileNames) {
                File file = new File(fileName);
                if ((file != null) && (file.getName().toLowerCase().endsWith(".tif"))) {
                    Files.copy(file.toPath(), new File(localPath + file.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
            }

        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil copyBackupTifToInstanceFolder."  + e.getMessage());
        }
    }

    public void injectBackupTIFToPages(Document document) {
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil injectBackupTIFToPages: " + bid);
            Element docRoot = document.getRootElement();
            int maxSetNumber = 1;
            int maxDocNumber = 1;
            int maxPageNumber = 0;
            List<Element> docList = docRoot.getChild(DOCUMENTS).getChildren(DOCUMENT);
            LOGGER.info("injectBackupTIFToPages xml document list size: " + docList.size());
            HashSet<String> newFileNameSet = new HashSet<>();
            for (Element doc : docList) {
                int setNumber = getSetNumber(doc);
                if (setNumber > maxSetNumber) {
                    maxSetNumber = setNumber;
                }
                int docNumber = getStrNumber(doc.getChildText(IDENTIFIER));
                if (docNumber > maxDocNumber) {
                    maxDocNumber = docNumber;
                }
                List<Element> pageList = doc.getChild(PAGES).getChildren(PAGE);
                for (Element page : pageList) {
                    if (StringUtils.isNotBlank(page.getChildText("NewFileName"))) {
                        newFileNameSet.add(page.getChildText("NewFileName"));
                    }
                    int pageID = getStrNumber(page.getChildText(IDENTIFIER));
                    if (pageID > maxPageNumber) {
                        maxPageNumber = pageID;
                    }
                }
            }
            String localPath = docRoot.getChildText(BATCH_LOCAL_PATH) + File.separatorChar + bid;
            File folder = new File(localPath);
            LOGGER.info("looking for tif file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            Collections.sort(listOfFiles);
            Element pageNode = null;
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".tif")) {
                    if (!newFileNameSet.contains(file.getName())) {
                        if (pageNode == null) {
                            Element newDoc = injectNewDocumentNode(document, "", "", "DOC" + (maxDocNumber + 1), maxSetNumber);
                            if (newDoc != null) {
                                pageNode = new Element(PAGES);
                                newDoc.addContent(pageNode);
                            }
                        }
                        maxPageNumber = maxPageNumber + 1;
                        Element page = new Element(PAGE);
                        OCRUtils.updateElementToDoc(page, IDENTIFIER, "PG" + maxPageNumber);
                        OCRUtils.updateElementToDoc(page, "OldFileName", file.getName());
                        OCRUtils.updateElementToDoc(page, "NewFileName", file.getName());
                        if (pageNode != null) {
                            pageNode.addContent(page);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil injectBackupTIFToPages."  + e.getMessage());
        }
    }

    public void replaceFinalFolderForTIF(Document document) {
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil replaceFinalFolderForTIF: " + bid);
            Element docRoot = document.getRootElement();
            List<Element> docList = docRoot.getChild(DOCUMENTS).getChildren(DOCUMENT);
            for (Element doc : docList) {
                List<Element> pageList = doc.getChild(PAGES).getChildren(PAGE);
                if ((pageList != null) && (pageList.size() > 0)) {
                    // new added doc and pages have no SourceFileID
                    if (StringUtils.isBlank(pageList.get(0).getChildText("SourceFileID"))) {
                        OCRUtils.updateElementToDoc(doc, IDENTIFIER, "NEXT_DOC1");
                        String multiPagePdfFile = doc.getChildText(MULTIPAGEPDFFILE);
                        if (StringUtils.isNotBlank(multiPagePdfFile)) {
                            OCRUtils.updateElementToDoc(doc, MULTIPAGEPDFFILE, multiPagePdfFile.replaceAll("_documentDOC\\d.*\\.pdf$", "_documentNEXT_DOC1.pdf"));
                        }
                        String finalMultiPagePdfFilePath = doc.getChildText("FinalMultiPagePdfFilePath");
                        if (StringUtils.isNotBlank(finalMultiPagePdfFilePath)) {
                            String newFinalMultiPagePdfFilePath = finalMultiPagePdfFilePath.replaceAll("_DOC\\d.*\\.pdf$", "_NEXT_DOC1.pdf");
                            OCRUtils.updateElementToDoc(doc, FINAL_MULTIPAGE_PDFFILEPATH, newFinalMultiPagePdfFilePath);
                            File finalMultiPagePdfFile = new File(finalMultiPagePdfFilePath);
                            if (finalMultiPagePdfFile != null) {
                                if (finalMultiPagePdfFile.renameTo(new File(newFinalMultiPagePdfFilePath))) {
                                    LOGGER.info("replaceFinalFolderForTIF renamed " + finalMultiPagePdfFilePath + " to " + newFinalMultiPagePdfFilePath);
                                }
                                if (finalMultiPagePdfFile.delete()) {
                                    LOGGER.info("replaceFinalFolderForTIF deleted " + finalMultiPagePdfFilePath);
                                }
                            }
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil replaceFinalFolderForTIF."  + e.getMessage());
        }
    }

    public void replaceFinalFolderForPDF(Document document) {
        int noPageRemove = PAGE_LIMIT;
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil replaceFinalFolder: " + bid);
            String finalFilePath = getFinalFilePath(document);
            Element docRoot = document.getRootElement();
            int fileCount = 1;
            int maxSetNumber = 1;
            List<Element> docList = docRoot.getChild(DOCUMENTS).getChildren(DOCUMENT);
            LOGGER.info("replaceFinalFolder xml document list size: " + docList.size());
            HashSet<String> PdfFileNameSet = new HashSet<>();
            for (Element doc : docList) {
                int setNumber = getSetNumber(doc);
                if (setNumber > maxSetNumber) {
                    maxSetNumber = setNumber;
                }
                if (StringUtils.isNotBlank(doc.getChildText(MULTIPAGEPDFFILE))) {
                    PdfFileNameSet.add(doc.getChildText(MULTIPAGEPDFFILE));
                }
            }
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            LOGGER.info("looking for pdf file in:" + folder.getAbsolutePath());
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
                if (file.getName().toLowerCase().endsWith(".pdf")) {
                    String newFileName = bid + "_documentNEXT_DOC" + Integer.toString(fileCount) + ".pdf";
                    String newFilePath = finalFilePath + File.separatorChar + bid + "_NEXT_DOC" + Integer.toString(fileCount) + ".pdf";
                    Files.copy(file.toPath(), new File(newFilePath).toPath(), StandardCopyOption.REPLACE_EXISTING);
                    if (noPageRemove > 0) {
                        noPageRemove = deleteFirstPagesForFile(new File(newFilePath), noPageRemove);
                    }
                    if (noPageRemove == 0) {
                        if (!PdfFileNameSet.contains(newFileName)) {
                            injectNewDocumentNode(document, newFileName, newFilePath, "NEXT_DOC" + fileCount, maxSetNumber);
                        }
                        fileCount = fileCount + 1;
                    }
                    // when the pdf pageNo exactly equals to noPageRemove, should not injectNewDocumentNode, thus return -1; then change back to 0
                    if (noPageRemove < 0) {
                        noPageRemove = 0;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil replaceFinalFolder."  + e.getMessage());
        }
    }

    public Element injectNewDocumentNode(Document document, String fileName, String filePath, String fileID, int setNumber) {
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil injectNewDocumentNode: ");
            Element docRoot = document.getRootElement();
            Element docsNode = docRoot.getChild(DOCUMENTS);
            Element doc = new Element(DOCUMENT);
            OCRUtils.updateElementToDoc(doc,IDENTIFIER, fileID);
            OCRUtils.updateElementToDoc(doc,TYPE,"Trade_SUPPORTING_DOCUMENTS");
            OCRUtils.updateElementToDoc(doc,DESCRIPTION,"Trade_SUPPORTING_DOCUMENTS");
            OCRUtils.updateElementToDoc(doc,CONFIDENCE,"0");
            OCRUtils.updateElementToDoc(doc,CONFIDENCE_THRESHOLD,"100");
            OCRUtils.updateElementToDoc(doc,VALID,"true");
            OCRUtils.updateElementToDoc(doc,REVIEWED,"true");
            OCRUtils.updateElementToDoc(doc,REVIEWED_BY,"SYSTEM");
            OCRUtils.updateElementToDoc(doc,VALIDATED_BY,"SYSTEM");
            OCRUtils.updateElementToDoc(doc,ERRORMESSAGE,"");
            OCRUtils.updateElementToDoc(doc,DOCUMENT_DISPLAY_INFO,"");
            injectSetNumberField(doc, setNumber);
            if (StringUtils.isNotBlank(fileName) && StringUtils.isNotBlank(filePath)) {
                OCRUtils.updateElementToDoc(doc,PAGES,"");
                OCRUtils.updateElementToDoc(doc, MULTIPAGEPDFFILE, fileName);
                OCRUtils.updateElementToDoc(doc, FINAL_MULTIPAGE_PDFFILEPATH, filePath);
            }
            docsNode.addContent(doc);
            return doc;
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil injectNewDocumentNode."  + e.getMessage());
        }
        return null;
    }

    public void injectSetNumberField(Element doc, int setNumber) {
        Element dlfNode = new Element(DOCUMENTLEVELFIELDS);
        Element dlf = new Element(DOCUMENTLEVELFIELD);
        OCRUtils.updateElementToDoc(dlf, NAME, "SetNumber");
        OCRUtils.updateElementToDoc(dlf, VALUE, Integer.toString(setNumber));
        OCRUtils.updateElementToDoc(dlf, TYPE, "STRING");
        OCRUtils.updateElementToDoc(dlf, OCR_CONFIDENCE_THRESHOLD, "90");
        OCRUtils.updateElementToDoc(dlf, OCR_CONFIDENCE, "100");
        OCRUtils.updateElementToDoc(dlf, "FieldOrderNumber", "0");
        OCRUtils.updateElementToDoc(dlf, FORCE_REVIEW, "false");
        OCRUtils.updateElementToDoc(dlf, "FieldValueChangeScript", "false");
        OCRUtils.updateElementToDoc(dlf, "ExtractionName", "Key Value Extraction");
        OCRUtils.updateElementToDoc(dlf, CATEGORY, "Group 1");
        dlfNode.addContent(dlf);
        doc.addContent(dlfNode);
    }

    public int getSetNumber(Element doc) {
        try {
            Element dlfSetNumber = OCRUtils.getDocField(doc, "SetNumber");
            String str = dlfSetNumber.getChildText(VALUE);
            return getStrNumber(str);
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getSetNumber."  + e.getMessage());
        }
        return -1;
    }

    public int getStrNumber(String str) {
        try {
            if (StringUtils.isNotBlank(str)) {
                int setNumber = Integer.parseInt(str.replaceAll("\\D", ""));
                return setNumber;
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getSetNumber."  + e.getMessage());
        }
        return -1;
    }

    public String getFinalFilePath(Document document) {
        try {
            LOGGER.info("************* Start HighwayPageLimitUtil getFinalFilePath: ");
            Element docRoot = document.getRootElement();
            List<Element> docList = docRoot.getChild(DOCUMENTS).getChildren(DOCUMENT);
            if (docList != null) {
                String finalFilePath = docList.get(0).getChildText(FINAL_MULTIPAGE_PDFFILEPATH);
                if (StringUtils.isNotBlank(finalFilePath)) {
                    File finalFile = new File(finalFilePath);
                    return finalFile.getParentFile().getAbsolutePath();
                }
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getFinalFilePath."  + e.getMessage());
        }
        return "";
    }
    
	public SortedMap<String, List<FilePageObject>> getFilePageMappingForDocuments(Document document) {
		LOGGER.info("************* Start HighwayPageLimitUtil getFilePageMappingForDocuments: ");
		SortedMap<String, List<FilePageObject>> result = new TreeMap<String, List<FilePageObject>>();
		try {
			Element docRoot = document.getRootElement();
			String bid = OCRUtils.getBatchClassInstanceId(document);
			List<Element> docList = docRoot.getChild(DOCUMENTS).getChildren(DOCUMENT);	
			for (Element doc : docList) {
				String docID = doc.getChildText(IDENTIFIER);
				String strDocFileName = bid + "_" + docID + ".pdf";
				if (!result.containsKey(strDocFileName)) {
					result.put(strDocFileName, new ArrayList<FilePageObject>());
				}
				List<Element> pageList = doc.getChild(PAGES).getChildren(PAGE);
                for (Element page : pageList) {
                    if (StringUtils.isNotBlank(page.getChildText("OldFileName"))) {
                    	FilePageObject filePageObject = getFilePageObjectForPage(page);
                    	if (filePageObject != null) {
                    		result.get(strDocFileName).add(filePageObject);
                    	}
                    }
                }
			}
			return result;
		} catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getFilePageMappingForDocuments."  + e.getMessage());		
		}
		return null;
	}
	
	public void mergeFilePageMapping(SortedMap<String, List<FilePageObject>> fpMap, String currentDir, String finalDir) {
		LOGGER.info("************* Start HighwayPageLimitUtil mergeFilePageMapping: ");
		PDDocument dstDoc = null;
		PDDocument srcDoc = null;
		try {
			File folder = new File(currentDir);
			List<File> listOfFiles = OCRUtils.getFileLists(folder);
			for (String newFileName : fpMap.keySet()) {
				LOGGER.info("HighwayPageLimitUtil mergeFilePageMapping: " + newFileName + "-" + fpMap.get(newFileName).size());
				dstDoc = new PDDocument();
				srcDoc = new PDDocument();
				String srcPdf = "";
				for (FilePageObject fpo : fpMap.get(newFileName)) {
					if (!srcPdf.equalsIgnoreCase(fpo.getFileName())) {
						for (File file : listOfFiles) {
	                        if (file.getName().equalsIgnoreCase(fpo.getFileName())) {
	                        	srcPdf = file.getName();
	    						srcDoc = PDDocument.load(file);
	                        }
						}
					}
					dstDoc.addPage(srcDoc.getPage(fpo.getPage()));
				}
				dstDoc.save(new File(finalDir + File.separatorChar + newFileName));
			}
		} catch (Exception e) {
			LOGGER.error("*************  Error occurred in HighwayPageLimitUtil mergeFilePageMapping."  + e.getMessage());
		}
		try {
    		dstDoc.close();    	    
    	} catch (Exception e) {
	    		
	    }
		try {
			srcDoc.close();
		} catch (Exception e) {
    		
	    }
	}
	
	static public FilePageObject getFilePageObjectForPage(Element page) {
        try {
            String filename = page.getChild(OLD_FILE_NAME).getText();
            String stpageno = StringUtils.substring(filename, filename.length()-14+1, filename.length()-14+5);
            filename = StringUtils.substring(filename, 0, filename.length()-14) + ".pdf";
            // xml page no start from 1, normal index start from 0
            int pageno = Integer.parseInt(stpageno) - 1;
            FilePageObject filePageObject = new FilePageObject();
            filePageObject.setFileName(filename);
            filePageObject.setPage(pageno);
            return filePageObject;
        } catch (Exception e){
            // LOGGER.error();
        }
        return null;
    }
	
	static public class FilePageObject {
		String fileName;
		int page;
		public String getFileName() {
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public int getPage() {
			return page;
		}
		public void setPage(int page) {
			this.page = page;
		}
	}
	
    public int getPageNoFromReport(Document document) {
    	int res = 0;
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil getPageNoFromReport: " + bid);
    		// discourage to call database every time
            // res = new CustomService().getPageNoForBatchInstance(bid);
            RepTransactionDetails repTransactionDetails = getBatchSourceAndPagesAsBatchLevelFields(document);
            res = Integer.parseInt(repTransactionDetails.getPages());
            LOGGER.info("getPageNoFromReport: " + bid + " : " + res);
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getPageNoFromReport." + e.getMessage());
        }
        return res;    
    }
    
    public int countTifFileInBackupFolder(Document document) {
    	int res = 0;
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil countTifFileInBackupFolder: " + bid);
            Element docRoot = document.getRootElement();
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH) + File.separatorChar + "_backup";
            File folder = new File(currentDir);
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            String fileExtension = ".tif";
            if (isBackupExist(document)) {
            	fileExtension = ".tifbk";
            }
            LOGGER.info("looking for " + fileExtension +" file in:" + folder.getAbsolutePath());
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
            	LOGGER.info("countTifFileInBackupFolder: " + file.getAbsolutePath());
            	if (file.getName().toLowerCase().endsWith(fileExtension)) {
            		res = res + 1;
            	}
            }
            LOGGER.info("countTifFileInBackupFolder: " + bid + " : " + res);
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil countTifFileInBackupFolder." + e.getMessage());
        }
        return res;
    }
    
    public SortedMap<String, String> mapInstanceFileBackupFile(Document document) {
    	SortedMap<String, String> res = new TreeMap<String, String>();
        try {
            String bid = OCRUtils.getBatchClassInstanceId(document);
            LOGGER.info("************* Start HighwayPageLimitUtil mapInstanceFileBackupFile: " + bid);
            Element docRoot = document.getRootElement();
            String localPath = docRoot.getChildText(BATCH_LOCAL_PATH);
            localPath = localPath + File.separatorChar + bid + File.separatorChar;
            String currentDir = docRoot.getChildText(UNC_FOLDER_PATH);
            currentDir = currentDir + File.separatorChar + "_backup" + File.separatorChar;;
            File folder = new File(localPath);
            List<File> listOfFiles = OCRUtils.getFileLists(folder);
            LOGGER.info("looking for tif file in:" + folder.getAbsolutePath());
            Collections.sort(listOfFiles);
            for (File file : listOfFiles) {
            	LOGGER.info("countTifFileInBackupFolder: " + file.getAbsolutePath());
            	if (file.getName().toLowerCase().endsWith(".tif")) {
            		String imageFileName = convertFileNameFromInstanceFolderToBackupFolder(file.getName(), ".tif");
            		imageFileName = currentDir + imageFileName;
                	LOGGER.info("countTifFileInBackupFolder: " + file.getAbsolutePath() + " : " + imageFileName);
            		res.put(file.getAbsolutePath(), imageFileName);
            	}
            }
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil mapInstanceFileBackupFile." + e.getMessage());
        }
        return res;
    }
    
    public String convertFileNameFromInstanceFolderToBackupFolder(String fileName, String fileExtension) {
    	String res = fileName;
    	try {
    		if (!fileExtension.startsWith(".")) {
    			fileExtension = "." + fileExtension;
    		}
    		res = res.replaceAll("^.*_", "").replaceAll("(?i)" + fileExtension + "$", "");
    		// [BI]_0.tif -> Image0000001.tif, ... , [BI]_10.tif -> Image0000011.tif
    		int fileNo = Integer.parseInt(res.replaceAll("\\D", "")) + 1;
    		res = "" + fileNo;
    		int addingZero = 7 - res.length();
    		for (int i=0; i<addingZero; i++) {
    			res = "0" + res;
    		}
    		res = "Image" + res + fileExtension;
    	} catch (Exception e) {
    		LOGGER.error("*************  Error occurred in HighwayPageLimitUtil convertFileNameFromInstanceFolderToBackupFolder." + e.getMessage());
    	}
    	return res;
    }
	
    public boolean isScannedPageCountMissing(Document document) {
    	boolean result = false;
    	Element rootNode = document.getRootElement();
		String bid = OCRUtils.getBatchClassInstanceId(document);
		LOGGER.info("************* Start HighwayPageLimitUtil isScannedPageCountMissing: " + bid);     
		try {
	        if (WEBSCANNER.equals(getBatchSourceForHighway(document))) {
	        	int countInReport = getPageNoFromReport(document);
	        	int countInBackupFolder = countTifFileInBackupFolder(document);
	        	if (countInReport > countInBackupFolder) {
	    			List<Element> docList = rootNode.getChild(DOCUMENTS).getChildren(DOCUMENT);
					result = true;
	    			for (Element doc : docList) {
	    				OCRUtils.updateElementToDoc(doc, VALID, FALSE);
	    				OCRUtils.updateElementToDoc(doc, ERRORMESSAGE, "Page missing during scanning, please reject and redo scanning");
	    				List<Element> dlfList = doc.getChild(DOCUMENTLEVELFIELDS).getChildren(DOCUMENTLEVELFIELD);
	    		        for (Element dlf : dlfList) {
		    				OCRUtils.updateElementToDoc(dlf, MESSAGE, "Page missing during scanning, please reject and redo scanning");
	    					OCRUtils.setLessConfLevel(dlf);
	    				}
	    			}
	        	}
	        }
		} catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil isScannedPageCountMissing." + e.getMessage());
        }
        return result;
    }
    
    // for Highway flow, sometime the batch source will change to "UNC Folder"
    public String getBatchSourceForHighway(Document document) {
    	String result = "";
    	try {
    		String bid = OCRUtils.getBatchClassInstanceId(document);
	    	Element rootNode = document.getRootElement();
	    	result = rootNode.getChildText(OCRConstants.BATCHSOURCE);
	    	LOGGER.info("getBatchSourceForHighway xml " + bid + ":" + result);
	    	if ("UNC Folder".equals(result)) {
	    		// discourage to call database every time
		    	// RepTransactionDetails repTransactionDetails = new CustomService().getRepBatchStatusByBID(bid);
	    		RepTransactionDetails repTransactionDetails = getBatchSourceAndPagesAsBatchLevelFields(document);
	    		if (repTransactionDetails != null) {
		    		result = repTransactionDetails.getBatch_source();
		    	}
    		}
	    	LOGGER.info("getBatchSourceForHighway db " + bid + ":" + result);
    	} catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getBatchSourceForHighway." + e.getMessage());
        }
    	return result;
    }
    
    // add batch_source and pages in batch level fields, if not exist then refer to rep_batch_status
    public RepTransactionDetails getBatchSourceAndPagesAsBatchLevelFields(Document document) {
    	RepTransactionDetails repTransactionDetails = new RepTransactionDetails();
    	try {
    		String bid = OCRUtils.getBatchClassInstanceId(document);
	    	Element rootNode = document.getRootElement();
	    	LOGGER.info("getRepTransactionDetailsAsBatchLevelFields: " + bid);
	    	Element batchLevelFields = rootNode.getChild(BATCHLEVELFIELDS);
    		if (batchLevelFields == null) {
    			batchLevelFields = new Element(BATCHLEVELFIELDS);
    			rootNode.addContent(batchLevelFields);
    		}
    		List<Element> blfList = batchLevelFields.getChildren(OCRConstants.BATCHLEVELFIELD);
    		for (Element blf : blfList) {
    			String blfName = blf.getChildText(NAME);
    			if ("BatchSource".equals(blfName)) {
    				repTransactionDetails.setBatch_source(blf.getChildText(VALUE));
    			}
    			if ("Pages".equals(blfName)) {
    				repTransactionDetails.setPages(blf.getChildText(VALUE));
    			}
    		}
    		LOGGER.info("getRepTransactionDetailsAsBatchLevelFields xml " + bid + " : " 
    				+ repTransactionDetails.getBatch_source() + " : " + repTransactionDetails.getPages());
    		if ((StringUtils.isBlank(repTransactionDetails.getBatch_source())) || 
    				(StringUtils.isBlank(repTransactionDetails.getPages()))) {
    			repTransactionDetails = new CustomService().getRepBatchStatusByBID(bid);
    			Element blfBatchSource = new Element(BATCHLEVELFIELD);
    	        OCRUtils.updateElementToDoc(blfBatchSource, NAME, "BatchSource");
    	        OCRUtils.updateElementToDoc(blfBatchSource, VALUE, repTransactionDetails.getBatch_source());
    	        OCRUtils.updateElementToDoc(blfBatchSource, TYPE, "STRING");
    	        Element blfPages = new Element(BATCHLEVELFIELD);
    	        OCRUtils.updateElementToDoc(blfPages, NAME, "Pages");
    	        OCRUtils.updateElementToDoc(blfPages, VALUE, repTransactionDetails.getPages());
    	        OCRUtils.updateElementToDoc(blfPages, TYPE, "STRING");
    	        batchLevelFields.addContent(blfBatchSource);
    	        batchLevelFields.addContent(blfPages);
    		}
    	} catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageLimitUtil getBatchStatusAsBatchLevelFields." + e.getMessage());
        }
        return repTransactionDetails;
    }

}
