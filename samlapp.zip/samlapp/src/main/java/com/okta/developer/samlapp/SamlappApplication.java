package com.okta.developer.samlapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamlappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamlappApplication.class, args);
	}

}
