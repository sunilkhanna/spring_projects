package sg.com.dbs.ocr.scripting.batchclass.common.highway;

import com.ephesoft.dcma.script.IJDomScript;
import com.ephesoft.dcma.util.logger.EphesoftLogger;
import com.ephesoft.dcma.util.logger.ScriptLoggerFactory;
import org.jdom.Document;
import org.jdom.Element;
import sg.com.dbs.ocr.constants.OCRConstants;
import sg.com.dbs.ocr.scripting.CustomService;
import sg.com.dbs.ocr.scripting.MakerCheckerUtil;
import sg.com.dbs.ocr.util.OCRUtils;
import static sg.com.dbs.ocr.scripting.batchclass.common.highway.HighwayConstants.*;

public class HighwayPageProcessing implements IJDomScript {

    private static final EphesoftLogger LOGGER = ScriptLoggerFactory.getLogger(HighwayPageProcessing.class);

    /**
     * The <code>execute</code> method will execute the script written by the writer
     * at run time with new compilation of java file. It will execute the java file
     * dynamically after new compilation.
     *
     * @param document {@link Document}
     */

    public Object execute(Document document, String methodName, String documentIdentifier) {
        Exception exception = null;
        try {
            LOGGER.info("************* Start HighwayPageProcessing execute: " + OCRUtils.getBatchClassInstanceId(document));
            Element rootNode = document.getRootElement();
            String batchClassName = rootNode.getChildText(OCRConstants.BATCH_CLASS_NAME);
            String batchInstanceIdentifier = rootNode.getChildText(OCRConstants.BATCH_INSTANCE_IDENTIFIER);
            MakerCheckerUtil scriptUtil = new MakerCheckerUtil();
            String role = scriptUtil.getBatchClassRole(batchClassName, "Maker");
            if (role != null) {
                scriptUtil.assignBatchInstanceGroup(batchInstanceIdentifier, role);
                scriptUtil.setBatchInstanceTaskType(batchInstanceIdentifier, "Maker");
            }
            (new CustomService()).repBatchStatusCreated(document);
            if (!OCRUtils.isFromEmail(document)) {
                HighwayPageLimitUtil highwayPageLimitUtil = new HighwayPageLimitUtil();
                highwayPageLimitUtil.setPageLimitFromCustomizedConfiguration();
                String batchSource = new HighwayPageLimitUtil().getBatchSourceForHighway(document);
                if ((UPLOADBATCH.equals(batchSource)) || (WEBSERVICE.equals(batchSource))) {
                    highwayPageLimitUtil.deleteRedundantPagesForPDF(document);
                } else if (WEBSCANNER.equals(batchSource)) {
                    highwayPageLimitUtil.deleteRedundantPagesForTIF(document);
                }
            }
            LOGGER.info("*************  Successfully finished the HighwayPageProcessing execute." + OCRUtils.getBatchClassInstanceId(document));
        } catch (Exception e) {
            LOGGER.error("*************  Error occurred in HighwayPageProcessing execute." + e.getMessage());
            exception = e;
        }
        return exception;
    }
}