package com.okta.developer.samlapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamlappApplicationTests {

	@Test
	void contextLoads() {
	}

}
