package io.sunil.productservice;

public class Product {

	private String productName;
	private String productId;

	public String getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Product(String productName,String productId) {
		this.productId=productId;
		this.productName=productName;
	}

}
