package io.sunil.productservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.discovery.DiscoveryClient;
import com.netflix.discovery.EurekaClient;

@SpringBootApplication
//@EnableDiscoveryClient
@EnableEurekaClient
@RestController
public class ProductServiceApplication {

	
	@Autowired
	private EurekaClient discoveryClient;
	
	@Bean
	//@LoadBalanced
	public RestTemplate restTemplate() {
		
		return new RestTemplate();
	}
	
	@Autowired
	private RestTemplate restTemplate;

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

	@GetMapping("/product")
	public Product product(@RequestParam(value = "productName", defaultValue = "World") String productName) {
	
		/**
		 *Client side discovery 
			discoveryClient.getNextServerFromEureka("product-inventory-service", false);
		*/
		String o = this.restTemplate.getForObject("http://product-inventory-service/inventory/123", String.class);
		System.out.println("Response from another service :: " + o);
		return new Product(productName, "121");// String.format("ProductName %s!", productName);
	}
}
