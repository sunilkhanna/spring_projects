package io.sunil.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.sunil.productservice.Product;

@SpringBootApplication
@RestController
public class UserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiceApplication.class, args);
	}

	@GetMapping("/user")
	public String product(@RequestParam(value = "userName", defaultValue = "Khanna") String userName) {
		return userName;//new Product(productName, "121");// String.format("ProductName %s!", productName);
	}

}
